# Netflix-Intro-Animation
Netflix Intro Animation-Pure CSS
